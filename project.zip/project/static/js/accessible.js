/**
 * Скрипт для версии сайта для слабовидящих
 * ГОСТ Р 52872-2012
 */

document.addEventListener('DOMContentLoaded', function() {
    // Получаем текущие настройки из localStorage
    const savedScheme = localStorage.getItem('accessibleScheme') || 'scheme-1';
    const savedFontSize = localStorage.getItem('accessibleFontSize') || 'font-medium';
    const savedImages = localStorage.getItem('accessibleImages') || 'true';
    
    // Применяем сохраненные настройки
    document.body.className = savedScheme + ' ' + savedFontSize;
    
    if (savedImages === 'false') {
        document.body.classList.add('hide-images');
    }
    
    // Обработчики для смены цветовой схемы
    const schemeButtons = document.querySelectorAll('[data-scheme]');
    schemeButtons.forEach(button => {
        button.addEventListener('click', function() {
            const scheme = this.getAttribute('data-scheme');
            
            // Удаляем все классы схем
            document.body.classList.remove('scheme-1', 'scheme-2', 'scheme-3', 'scheme-4', 'scheme-5');
            
            // Добавляем новую схему
            document.body.classList.add(scheme);
            
            // Сохраняем в localStorage
            localStorage.setItem('accessibleScheme', scheme);
            
            // Обновляем стили кнопок
            updateButtonStyles();
        });
    });
    
    // Обработчики для смены размера шрифта
    const fontButtons = document.querySelectorAll('[data-font-size]');
    fontButtons.forEach(button => {
        button.addEventListener('click', function() {
            const fontSize = this.getAttribute('data-font-size');
            
            // Удаляем все классы размеров
            document.body.classList.remove('font-small', 'font-medium', 'font-large', 'font-xlarge');
            
            // Добавляем новый размер
            document.body.classList.add(fontSize);
            
            // Сохраняем в localStorage
            localStorage.setItem('accessibleFontSize', fontSize);
        });
    });
    
    // Кнопка увеличения шрифта
    const increaseFontBtn = document.getElementById('increase-font');
    if (increaseFontBtn) {
        increaseFontBtn.addEventListener('click', function() {
            const sizes = ['font-small', 'font-medium', 'font-large', 'font-xlarge'];
            let currentIndex = -1;
            
            sizes.forEach((size, index) => {
                if (document.body.classList.contains(size)) {
                    currentIndex = index;
                }
            });
            
            if (currentIndex < sizes.length - 1) {
                document.body.classList.remove(sizes[currentIndex]);
                document.body.classList.add(sizes[currentIndex + 1]);
                localStorage.setItem('accessibleFontSize', sizes[currentIndex + 1]);
            }
        });
    }
    
    // Кнопка уменьшения шрифта
    const decreaseFontBtn = document.getElementById('decrease-font');
    if (decreaseFontBtn) {
        decreaseFontBtn.addEventListener('click', function() {
            const sizes = ['font-small', 'font-medium', 'font-large', 'font-xlarge'];
            let currentIndex = -1;
            
            sizes.forEach((size, index) => {
                if (document.body.classList.contains(size)) {
                    currentIndex = index;
                }
            });
            
            if (currentIndex > 0) {
                document.body.classList.remove(sizes[currentIndex]);
                document.body.classList.add(sizes[currentIndex - 1]);
                localStorage.setItem('accessibleFontSize', sizes[currentIndex - 1]);
            }
        });
    }
    
    // Переключение отображения изображений
    const toggleImagesBtn = document.getElementById('toggle-images');
    if (toggleImagesBtn) {
        toggleImagesBtn.addEventListener('click', function() {
            const images = document.querySelectorAll('img');
            const isHidden = document.body.classList.contains('hide-images');
            
            if (isHidden) {
                document.body.classList.remove('hide-images');
                images.forEach(img => img.style.display = '');
                localStorage.setItem('accessibleImages', 'true');
                this.textContent = 'Скрыть изображения';
            } else {
                document.body.classList.add('hide-images');
                images.forEach(img => img.style.display = 'none');
                localStorage.setItem('accessibleImages', 'false');
                this.textContent = 'Показать изображения';
            }
        });
    }
    
    // Сброс настроек
    const resetBtn = document.getElementById('reset-settings');
    if (resetBtn) {
        resetBtn.addEventListener('click', function() {
            localStorage.removeItem('accessibleScheme');
            localStorage.removeItem('accessibleFontSize');
            localStorage.removeItem('accessibleImages');
            
            document.body.className = 'scheme-1 font-medium';
            document.querySelectorAll('img').forEach(img => img.style.display = '');
            
            if (toggleImagesBtn) {
                toggleImagesBtn.textContent = 'Скрыть изображения';
            }
        });
    }
    
    // Функция обновления стилей кнопок
    function updateButtonStyles() {
        const computedStyle = getComputedStyle(document.body);
        const bgColor = computedStyle.backgroundColor;
        const textColor = computedStyle.color;
        
        // Применяем цвета к кнопкам
        document.querySelectorAll('.accessibility-btn, .btn, .form-control').forEach(elem => {
            elem.style.borderColor = textColor;
            elem.style.color = textColor;
        });
    }
    
    // Обработчик для клавиатурной навигации
    document.addEventListener('keydown', function(e) {
        // Ctrl + '+' - увеличить шрифт
        if (e.ctrlKey && e.key === '+') {
            e.preventDefault();
            if (increaseFontBtn) increaseFontBtn.click();
        }
        
        // Ctrl + '-' - уменьшить шрифт
        if (e.ctrlKey && e.key === '-') {
            e.preventDefault();
            if (decreaseFontBtn) decreaseFontBtn.click();
        }
    });
    
    // Инициализация стилей
    updateButtonStyles();
});

