"""
URL configuration for СтройДом project.
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.views.generic import TemplateView

urlpatterns = [
    path('admin/', admin.site.urls),
    
    # Основные приложения
    path('', include('apps.main.urls')),
    path('services/', include('apps.services.urls')),
    path('projects/', include('apps.projects.urls')),
    path('news/', include('apps.news.urls')),
    path('contacts/', include('apps.contacts.urls')),
    path('users/', include('apps.users.urls')),
    
    # Карта сайта
    path('sitemap/', TemplateView.as_view(template_name='sitemap.html'), name='sitemap'),
]

# Обработчик 404
handler404 = 'apps.main.views.custom_404'

# Serve media files in development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

# Admin site customization
admin.site.site_header = "Панель управления СтройДом"
admin.site.site_title = "СтройДом Admin"
admin.site.index_title = "Добро пожаловать в панель управления"

