default_app_config = 'apps.news.apps.NewsConfig'

