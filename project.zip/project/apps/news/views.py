from django.shortcuts import render, get_object_or_404
from django.core.paginator import Paginator
from .models import News, NewsCategory


def news_list(request):
    """Список новостей"""
    news_list = News.objects.filter(is_published=True)
    
    # Фильтрация по категории
    category_slug = request.GET.get('category')
    selected_category = None
    if category_slug:
        selected_category = get_object_or_404(NewsCategory, slug=category_slug)
        news_list = news_list.filter(category=selected_category)
    
    # Пагинация
    paginator = Paginator(news_list, 10)  # 10 новостей на странице
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    # Все категории для фильтра
    categories = NewsCategory.objects.all()
    
    context = {
        'page_obj': page_obj,
        'news_list': page_obj,
        'categories': categories,
        'selected_category': selected_category,
    }
    return render(request, 'news/list.html', context)


def news_detail(request, slug):
    """Детальная страница новости"""
    news = get_object_or_404(News, slug=slug, is_published=True)
    
    # Увеличиваем счётчик просмотров
    news.views += 1
    news.save(update_fields=['views'])
    
    # Похожие новости
    related_news = News.objects.filter(
        is_published=True,
        category=news.category
    ).exclude(id=news.id)[:3]
    
    context = {
        'news': news,
        'related_news': related_news,
    }
    return render(request, 'news/detail.html', context)

