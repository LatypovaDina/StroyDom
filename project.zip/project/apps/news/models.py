from django.db import models
from django.urls import reverse
from apps.users.models import CustomUser


class NewsCategory(models.Model):
    """Категории новостей"""
    name = models.CharField('Название', max_length=100)
    slug = models.SlugField('URL', unique=True)
    order = models.IntegerField('Порядок', default=0)
    
    class Meta:
        verbose_name = 'Категория новостей'
        verbose_name_plural = 'Категории новостей'
        ordering = ['order', 'name']
    
    def __str__(self):
        return self.name


class News(models.Model):
    """Новости"""
    title = models.CharField('Заголовок', max_length=200)
    slug = models.SlugField('URL', unique=True)
    content = models.TextField('Содержание')
    excerpt = models.CharField('Краткое описание', max_length=300, blank=True)
    image = models.ImageField('Изображение', upload_to='news/', blank=True, null=True)
    category = models.ForeignKey(NewsCategory, on_delete=models.SET_NULL, null=True, blank=True, 
                                 related_name='news', verbose_name='Категория')
    author = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, 
                              related_name='news', verbose_name='Автор')
    is_published = models.BooleanField('Опубликовано', default=True)
    published_date = models.DateTimeField('Дата публикации', auto_now_add=True)
    updated_at = models.DateTimeField('Дата обновления', auto_now=True)
    views = models.IntegerField('Просмотры', default=0)
    is_featured = models.BooleanField('Избранная', default=False)
    
    class Meta:
        verbose_name = 'Новость'
        verbose_name_plural = 'Новости'
        ordering = ['-published_date']
    
    def __str__(self):
        return self.title
    
    def get_absolute_url(self):
        return reverse('news:detail', kwargs={'slug': self.slug})

