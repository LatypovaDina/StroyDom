from django.shortcuts import render, get_object_or_404
from django.views.generic import ListView, DetailView
from .models import Service


class ServiceListView(ListView):
    """Список услуг"""
    model = Service
    template_name = 'services/list.html'
    context_object_name = 'services'
    
    def get_queryset(self):
        return Service.objects.filter(is_active=True)


class ServiceDetailView(DetailView):
    """Детальная страница услуги"""
    model = Service
    template_name = 'services/detail.html'
    context_object_name = 'service'
    
    def get_queryset(self):
        return Service.objects.filter(is_active=True)


def service_list(request):
    """Список услуг"""
    services = Service.objects.filter(is_active=True)
    return render(request, 'services/list.html', {'services': services})


def service_detail(request, slug):
    """Детальная страница услуги"""
    service = get_object_or_404(Service, slug=slug, is_active=True)
    related_services = Service.objects.filter(is_active=True).exclude(id=service.id)[:3]
    
    context = {
        'service': service,
        'related_services': related_services,
    }
    return render(request, 'services/detail.html', context)

