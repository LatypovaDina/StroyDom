from django.db import models
from django.urls import reverse


class Service(models.Model):
    """Услуги компании"""
    name = models.CharField('Название', max_length=200)
    slug = models.SlugField('URL', unique=True)
    description = models.TextField('Описание')
    short_description = models.CharField('Краткое описание', max_length=300, blank=True)
    icon = models.CharField('Иконка (FontAwesome)', max_length=50, default='fa-tools')
    image = models.ImageField('Изображение', upload_to='services/', blank=True, null=True)
    price_from = models.DecimalField('Цена от (руб)', max_digits=10, decimal_places=2, blank=True, null=True)
    order = models.IntegerField('Порядок', default=0)
    is_active = models.BooleanField('Активна', default=True)
    created_at = models.DateTimeField('Дата создания', auto_now_add=True)
    updated_at = models.DateTimeField('Дата обновления', auto_now=True)
    
    class Meta:
        verbose_name = 'Услуга'
        verbose_name_plural = 'Услуги'
        ordering = ['order', 'name']
    
    def __str__(self):
        return self.name
    
    def get_absolute_url(self):
        return reverse('services:detail', kwargs={'slug': self.slug})


class ServiceFeature(models.Model):
    """Особенности услуги"""
    service = models.ForeignKey(Service, on_delete=models.CASCADE, related_name='features', verbose_name='Услуга')
    title = models.CharField('Заголовок', max_length=200)
    description = models.TextField('Описание', blank=True)
    order = models.IntegerField('Порядок', default=0)
    
    class Meta:
        verbose_name = 'Особенность услуги'
        verbose_name_plural = 'Особенности услуг'
        ordering = ['order']
    
    def __str__(self):
        return f"{self.service.name} - {self.title}"

