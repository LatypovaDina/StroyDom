from django.contrib import admin
from .models import Service, ServiceFeature


class ServiceFeatureInline(admin.TabularInline):
    model = ServiceFeature
    extra = 1


@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):
    list_display = ('name', 'price_from', 'order', 'is_active', 'created_at')
    list_filter = ('is_active', 'created_at')
    list_editable = ('order', 'is_active')
    search_fields = ('name', 'description')
    prepopulated_fields = {'slug': ('name',)}
    inlines = [ServiceFeatureInline]
    
    fieldsets = (
        ('Основная информация', {
            'fields': ('name', 'slug', 'short_description', 'description')
        }),
        ('Визуальное оформление', {
            'fields': ('icon', 'image')
        }),
        ('Настройки', {
            'fields': ('price_from', 'order', 'is_active')
        }),
    )


@admin.register(ServiceFeature)
class ServiceFeatureAdmin(admin.ModelAdmin):
    list_display = ('service', 'title', 'order')
    list_filter = ('service',)
    search_fields = ('title', 'description')

