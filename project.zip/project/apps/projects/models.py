from django.db import models
from django.urls import reverse


class Project(models.Model):
    """Реализованные проекты"""
    
    STATUS_CHOICES = (
        ('in_progress', 'В процессе'),
        ('completed', 'Завершён'),
    )
    
    title = models.CharField('Название', max_length=200)
    slug = models.SlugField('URL', unique=True)
    description = models.TextField('Описание')
    short_description = models.CharField('Краткое описание', max_length=300, blank=True)
    area = models.DecimalField('Площадь (м²)', max_digits=10, decimal_places=2, blank=True, null=True)
    floors = models.IntegerField('Этажей', default=1)
    bedrooms = models.IntegerField('Спален', default=1)
    bathrooms = models.IntegerField('Санузлов', default=1)
    price = models.DecimalField('Стоимость (руб)', max_digits=12, decimal_places=2, blank=True, null=True)
    location = models.CharField('Локация', max_length=200, blank=True)
    status = models.CharField('Статус', max_length=20, choices=STATUS_CHOICES, default='completed')
    main_image = models.ImageField('Главное изображение', upload_to='projects/')
    date_completed = models.DateField('Дата завершения', blank=True, null=True)
    created_at = models.DateTimeField('Дата создания', auto_now_add=True)
    updated_at = models.DateTimeField('Дата обновления', auto_now=True)
    views = models.IntegerField('Просмотры', default=0)
    is_featured = models.BooleanField('Избранный', default=False)
    
    class Meta:
        verbose_name = 'Проект'
        verbose_name_plural = 'Проекты'
        ordering = ['-created_at']
    
    def __str__(self):
        return self.title
    
    def get_absolute_url(self):
        return reverse('projects:detail', kwargs={'slug': self.slug})


class ProjectImage(models.Model):
    """Дополнительные изображения проекта"""
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='images', verbose_name='Проект')
    image = models.ImageField('Изображение', upload_to='projects/gallery/')
    title = models.CharField('Название', max_length=200, blank=True)
    order = models.IntegerField('Порядок', default=0)
    
    class Meta:
        verbose_name = 'Изображение проекта'
        verbose_name_plural = 'Изображения проектов'
        ordering = ['order']
    
    def __str__(self):
        return f"{self.project.title} - {self.title or 'Фото'}"

