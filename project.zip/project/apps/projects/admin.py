from django.contrib import admin
from .models import Project, ProjectImage


class ProjectImageInline(admin.TabularInline):
    model = ProjectImage
    extra = 3


@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ('title', 'status', 'area', 'price', 'is_featured', 'views', 'created_at')
    list_filter = ('status', 'is_featured', 'created_at')
    list_editable = ('is_featured',)
    search_fields = ('title', 'description', 'location')
    prepopulated_fields = {'slug': ('title',)}
    inlines = [ProjectImageInline]
    
    fieldsets = (
        ('Основная информация', {
            'fields': ('title', 'slug', 'short_description', 'description', 'main_image')
        }),
        ('Характеристики', {
            'fields': ('area', 'floors', 'bedrooms', 'bathrooms', 'location')
        }),
        ('Финансовая информация', {
            'fields': ('price', 'status', 'date_completed')
        }),
        ('Настройки', {
            'fields': ('is_featured',)
        }),
    )
    
    readonly_fields = ('views', 'created_at', 'updated_at')


@admin.register(ProjectImage)
class ProjectImageAdmin(admin.ModelAdmin):
    list_display = ('project', 'title', 'order')
    list_filter = ('project',)
    search_fields = ('project__title', 'title')

