from django.shortcuts import render, get_object_or_404
from django.core.paginator import Paginator
from .models import Project


def project_list(request):
    """Список проектов"""
    projects = Project.objects.filter(status='completed')
    
    # Фильтрация
    status = request.GET.get('status')
    if status:
        projects = projects.filter(status=status)
    
    # Пагинация
    paginator = Paginator(projects, 9)  # 9 проектов на странице
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'projects': page_obj,
    }
    return render(request, 'projects/list.html', context)


def project_detail(request, slug):
    """Детальная страница проекта"""
    project = get_object_or_404(Project, slug=slug)
    
    # Увеличиваем счётчик просмотров
    project.views += 1
    project.save(update_fields=['views'])
    
    # Похожие проекты
    related_projects = Project.objects.filter(
        status='completed'
    ).exclude(id=project.id)[:3]
    
    context = {
        'project': project,
        'related_projects': related_projects,
    }
    return render(request, 'projects/detail.html', context)

