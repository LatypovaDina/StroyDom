from django import forms
from .models import ContactMessage, ConstructionCalculation


class ContactForm(forms.ModelForm):
    """Форма обратной связи"""
    
    class Meta:
        model = ContactMessage
        fields = ('name', 'email', 'phone', 'subject', 'message')
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ваше имя'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Ваш email'}),
            'phone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ваш телефон'}),
            'subject': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Тема сообщения'}),
            'message': forms.Textarea(attrs={'class': 'form-control', 'rows': 5, 'placeholder': 'Ваше сообщение'}),
        }


class CalculatorForm(forms.ModelForm):
    """Форма калькулятора стоимости"""
    
    FOUNDATION_CHOICES = [
        ('strip', 'Ленточный'),
        ('slab', 'Плитный'),
        ('pile', 'Свайный'),
    ]
    
    WALL_MATERIAL_CHOICES = [
        ('brick', 'Кирпич'),
        ('block', 'Газобетон'),
        ('wood', 'Дерево (брус)'),
        ('frame', 'Каркас'),
    ]
    
    ROOF_CHOICES = [
        ('flat', 'Плоская'),
        ('gable', 'Двускатная'),
        ('hip', 'Вальмовая'),
        ('complex', 'Сложная'),
    ]
    
    foundation_type = forms.ChoiceField(
        label='Тип фундамента',
        choices=FOUNDATION_CHOICES,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    wall_material = forms.ChoiceField(
        label='Материал стен',
        choices=WALL_MATERIAL_CHOICES,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    roof_type = forms.ChoiceField(
        label='Тип кровли',
        choices=ROOF_CHOICES,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    class Meta:
        model = ConstructionCalculation
        fields = ('name', 'email', 'phone', 'area', 'floors', 'foundation_type', 'wall_material', 'roof_type')
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ваше имя'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Ваш email'}),
            'phone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ваш телефон'}),
            'area': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Площадь дома', 'min': '30', 'max': '1000'}),
            'floors': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Количество этажей', 'min': '1', 'max': '3'}),
        }
    
    def calculate_cost(self):
        """Расчёт примерной стоимости"""
        area = float(self.cleaned_data['area'])
        floors = self.cleaned_data['floors']
        foundation = self.cleaned_data['foundation_type']
        material = self.cleaned_data['wall_material']
        roof = self.cleaned_data['roof_type']
        
        # Базовая стоимость за м²
        base_cost_per_sqm = 35000
        
        # Коэффициенты
        foundation_coeffs = {'strip': 1.0, 'slab': 1.15, 'pile': 0.9}
        material_coeffs = {'brick': 1.2, 'block': 1.0, 'wood': 1.1, 'frame': 0.85}
        roof_coeffs = {'flat': 0.9, 'gable': 1.0, 'hip': 1.15, 'complex': 1.3}
        floors_coeff = 1 + (floors - 1) * 0.15
        
        # Итоговый расчёт
        total_cost = (
            area * base_cost_per_sqm *
            foundation_coeffs[foundation] *
            material_coeffs[material] *
            roof_coeffs[roof] *
            floors_coeff
        )
        
        return round(total_cost, 2)

