from django.db import models


class ContactMessage(models.Model):
    """Сообщения от клиентов"""
    name = models.CharField('Имя', max_length=100)
    email = models.EmailField('Email')
    phone = models.CharField('Телефон', max_length=20, blank=True)
    subject = models.CharField('Тема', max_length=200, blank=True)
    message = models.TextField('Сообщение')
    is_read = models.BooleanField('Прочитано', default=False)
    created_at = models.DateTimeField('Дата отправки', auto_now_add=True)
    replied_at = models.DateTimeField('Дата ответа', blank=True, null=True)
    
    class Meta:
        verbose_name = 'Сообщение'
        verbose_name_plural = 'Сообщения'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.name} - {self.subject or 'Без темы'}"


class ContactInfo(models.Model):
    """Контактная информация компании (синглтон)"""
    address = models.CharField('Адрес', max_length=300)
    phone = models.CharField('Телефон', max_length=100)
    email = models.EmailField('Email')
    work_hours = models.CharField('Часы работы', max_length=200, default='Пн-Пт: 9:00-18:00')
    map_iframe = models.TextField('Код карты (iframe)', blank=True,
                                   help_text='Вставьте код встраивания карты из Google Maps или Яндекс.Карты')
    
    # Социальные сети
    vk_url = models.URLField('VK', blank=True)
    telegram_url = models.URLField('Telegram', blank=True)
    instagram_url = models.URLField('Instagram', blank=True)
    facebook_url = models.URLField('Facebook', blank=True)
    
    class Meta:
        verbose_name = 'Контактная информация'
        verbose_name_plural = 'Контактная информация'
    
    def __str__(self):
        return 'Контактная информация'
    
    def save(self, *args, **kwargs):
        # Обеспечиваем только одну запись
        self.pk = 1
        super().save(*args, **kwargs)
    
    @classmethod
    def load(cls):
        obj, created = cls.objects.get_or_create(pk=1)
        return obj


class ConstructionCalculation(models.Model):
    """Сохранённые расчёты калькулятора"""
    name = models.CharField('Имя', max_length=100)
    email = models.EmailField('Email')
    phone = models.CharField('Телефон', max_length=20)
    
    # Параметры дома
    area = models.DecimalField('Площадь (м²)', max_digits=10, decimal_places=2)
    floors = models.IntegerField('Количество этажей')
    foundation_type = models.CharField('Тип фундамента', max_length=50)
    wall_material = models.CharField('Материал стен', max_length=50)
    roof_type = models.CharField('Тип кровли', max_length=50)
    
    # Расчёт
    estimated_cost = models.DecimalField('Расчётная стоимость (руб)', max_digits=12, decimal_places=2)
    created_at = models.DateTimeField('Дата расчёта', auto_now_add=True)
    is_contacted = models.BooleanField('Связались', default=False)
    
    class Meta:
        verbose_name = 'Расчёт стоимости'
        verbose_name_plural = 'Расчёты стоимости'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.name} - {self.area} м² - {self.estimated_cost} руб."

