from django.contrib import admin
from .models import ContactMessage, ContactInfo, ConstructionCalculation


@admin.register(ContactMessage)
class ContactMessageAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'subject', 'is_read', 'created_at')
    list_filter = ('is_read', 'created_at')
    list_editable = ('is_read',)
    search_fields = ('name', 'email', 'subject', 'message')
    readonly_fields = ('created_at',)
    date_hierarchy = 'created_at'
    
    fieldsets = (
        ('Отправитель', {
            'fields': ('name', 'email', 'phone')
        }),
        ('Сообщение', {
            'fields': ('subject', 'message')
        }),
        ('Статус', {
            'fields': ('is_read', 'replied_at')
        }),
    )


@admin.register(ContactInfo)
class ContactInfoAdmin(admin.ModelAdmin):
    fieldsets = (
        ('Основная информация', {
            'fields': ('address', 'phone', 'email', 'work_hours')
        }),
        ('Карта', {
            'fields': ('map_iframe',)
        }),
        ('Социальные сети', {
            'fields': ('vk_url', 'telegram_url', 'instagram_url', 'facebook_url')
        }),
    )
    
    def has_add_permission(self, request):
        # Разрешаем только одну запись
        return not ContactInfo.objects.exists()
    
    def has_delete_permission(self, request, obj=None):
        # Запрещаем удаление
        return False


@admin.register(ConstructionCalculation)
class ConstructionCalculationAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'area', 'floors', 'estimated_cost', 'is_contacted', 'created_at')
    list_filter = ('is_contacted', 'floors', 'created_at')
    list_editable = ('is_contacted',)
    search_fields = ('name', 'email', 'phone')
    readonly_fields = ('created_at',)
    date_hierarchy = 'created_at'
    
    fieldsets = (
        ('Клиент', {
            'fields': ('name', 'email', 'phone')
        }),
        ('Параметры дома', {
            'fields': ('area', 'floors', 'foundation_type', 'wall_material', 'roof_type')
        }),
        ('Расчёт', {
            'fields': ('estimated_cost', 'is_contacted')
        }),
    )

