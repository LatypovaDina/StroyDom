from django.shortcuts import render, redirect
from django.contrib import messages
from .models import ContactInfo
from .forms import ContactForm, CalculatorForm


def contacts(request):
    """Страница контактов"""
    contact_info = ContactInfo.load()
    
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Ваше сообщение успешно отправлено! Мы свяжемся с вами в ближайшее время.')
            return redirect('contacts:contacts')
    else:
        form = ContactForm()
    
    context = {
        'contact_info': contact_info,
        'form': form,
    }
    return render(request, 'contacts/contacts.html', context)


def calculator(request):
    """Калькулятор стоимости строительства"""
    estimated_cost = None
    
    if request.method == 'POST':
        form = CalculatorForm(request.POST)
        if form.is_valid():
            # Рассчитываем стоимость
            estimated_cost = form.calculate_cost()
            
            # Сохраняем расчёт
            calculation = form.save(commit=False)
            calculation.estimated_cost = estimated_cost
            calculation.save()
            
            messages.success(request, f'Примерная стоимость строительства: {estimated_cost:,.0f} руб. Наш менеджер свяжется с вами для уточнения деталей.')
    else:
        form = CalculatorForm()
    
    context = {
        'form': form,
        'estimated_cost': estimated_cost,
    }
    return render(request, 'contacts/calculator.html', context)

