from django.shortcuts import render
from django.db.models import Q
from .models import Banner, Advantage, CompanyInfo, TeamMember
from apps.projects.models import Project
from apps.news.models import News


def home(request):
    """Главная страница"""
    banners = Banner.objects.filter(is_active=True)
    advantages = Advantage.objects.all()[:6]
    recent_projects = Project.objects.filter(status='completed')[:3]
    recent_news = News.objects.filter(is_published=True)[:3]
    company_info = CompanyInfo.load()
    
    context = {
        'banners': banners,
        'advantages': advantages,
        'recent_projects': recent_projects,
        'recent_news': recent_news,
        'company_info': company_info,
    }
    return render(request, 'main/home.html', context)


def about(request):
    """О компании"""
    company_info = CompanyInfo.load()
    team_members = TeamMember.objects.all()
    advantages = Advantage.objects.all()
    
    context = {
        'company_info': company_info,
        'team_members': team_members,
        'advantages': advantages,
    }
    return render(request, 'main/about.html', context)


def search(request):
    """Поиск по сайту"""
    query = request.GET.get('q', '')
    results = []
    
    if query:
        # Поиск в проектах
        projects = Project.objects.filter(
            Q(title__icontains=query) | Q(description__icontains=query)
        )
        for project in projects:
            results.append({
                'title': project.title,
                'description': project.description[:200],
                'url': project.get_absolute_url(),
                'type': 'Проект'
            })
        
        # Поиск в новостях
        news = News.objects.filter(
            Q(title__icontains=query) | Q(content__icontains=query),
            is_published=True
        )
        for item in news:
            results.append({
                'title': item.title,
                'description': item.content[:200],
                'url': item.get_absolute_url(),
                'type': 'Новость'
            })
    
    context = {
        'query': query,
        'results': results,
        'count': len(results),
    }
    return render(request, 'main/search.html', context)


def custom_404(request, exception):
    """Обработчик 404 ошибки"""
    return render(request, '404.html', status=404)

