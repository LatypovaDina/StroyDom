from django.db import models


class Banner(models.Model):
    """Баннеры для главной страницы"""
    title = models.CharField('Заголовок', max_length=200)
    subtitle = models.CharField('Подзаголовок', max_length=300, blank=True)
    image = models.ImageField('Изображение', upload_to='banners/')
    link = models.CharField('Ссылка', max_length=200, blank=True)
    order = models.IntegerField('Порядок', default=0)
    is_active = models.BooleanField('Активен', default=True)
    
    class Meta:
        verbose_name = 'Баннер'
        verbose_name_plural = 'Баннеры'
        ordering = ['order']
    
    def __str__(self):
        return self.title


class TeamMember(models.Model):
    """Члены команды"""
    name = models.CharField('Имя', max_length=100)
    position = models.CharField('Должность', max_length=100)
    photo = models.ImageField('Фото', upload_to='team/')
    description = models.TextField('Описание', blank=True)
    order = models.IntegerField('Порядок', default=0)
    
    class Meta:
        verbose_name = 'Член команды'
        verbose_name_plural = 'Команда'
        ordering = ['order']
    
    def __str__(self):
        return f"{self.name} - {self.position}"


class Advantage(models.Model):
    """Преимущества компании"""
    title = models.CharField('Заголовок', max_length=100)
    description = models.TextField('Описание')
    icon = models.CharField('Иконка (FontAwesome класс)', max_length=50, default='fa-check')
    order = models.IntegerField('Порядок', default=0)
    
    class Meta:
        verbose_name = 'Преимущество'
        verbose_name_plural = 'Преимущества'
        ordering = ['order']
    
    def __str__(self):
        return self.title


class CompanyInfo(models.Model):
    """Информация о компании (синглтон)"""
    about_text = models.TextField('О компании')
    mission = models.TextField('Наша миссия', blank=True)
    vision = models.TextField('Наше видение', blank=True)
    years_experience = models.IntegerField('Лет опыта', default=10)
    completed_projects = models.IntegerField('Завершённых проектов', default=100)
    happy_clients = models.IntegerField('Довольных клиентов', default=150)
    
    class Meta:
        verbose_name = 'Информация о компании'
        verbose_name_plural = 'Информация о компании'
    
    def __str__(self):
        return 'Информация о компании'
    
    def save(self, *args, **kwargs):
        # Обеспечиваем только одну запись
        self.pk = 1
        super().save(*args, **kwargs)
    
    @classmethod
    def load(cls):
        obj, created = cls.objects.get_or_create(pk=1)
        return obj

