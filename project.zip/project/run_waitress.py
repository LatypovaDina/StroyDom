
import os
import sys

# Добавляем путь к проекту
sys.path.insert(0, os.path.dirname(__file__))

# Устанавливаем переменную окружения для Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')

# Импортируем Django WSGI приложение
from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()

if __name__ == '__main__':
    from waitress import serve
    
    # Запускаем Waitress на порту 8080
    serve(
        application,
        host='0.0.0.0',
        port=8080,
        threads=4,
        url_scheme='http'
    )

