"""
Скрипт для создания начальных данных для сайта СтройДом
Запуск: python initial_data_setup.py
"""
import os
import sys
import django

# Установка кодировки для Windows
if sys.platform == 'win32':
    sys.stdout.reconfigure(encoding='utf-8')

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings_production')
django.setup()

from django.contrib.auth import get_user_model
from apps.main.models import CompanyInfo, Advantage, Banner
from apps.services.models import Service, ServiceFeature
from apps.projects.models import Project
from apps.news.models import NewsCategory, News
from apps.contacts.models import ContactInfo

User = get_user_model()

print("Создание начальных данных для СтройДом...")

# Создаём пользователей
print("\n1. Создание пользователей...")
if not User.objects.filter(username='admin').exists():
    admin = User.objects.create_superuser(
        username='admin',
        email='admin@stroydom.ru',
        password='Admin2025!',
        first_name='Администратор',
        role='admin'
    )
    print("✓ Создан администратор: admin / Admin2025!")

if not User.objects.filter(username='manager').exists():
    manager = User.objects.create_user(
        username='manager',
        email='manager@stroydom.ru',
        password='Manager2025!',
        first_name='Иван',
        last_name='Петров',
        role='manager',
        is_staff=True
    )
    print("✓ Создан менеджер: manager / Manager2025!")

if not User.objects.filter(username='client').exists():
    client = User.objects.create_user(
        username='client',
        email='client@example.com',
        password='Client2025!',
        first_name='Алексей',
        last_name='Сидоров',
        role='client'
    )
    print("✓ Создан клиент: client / Client2025!")

# Информация о компании
print("\n2. Создание информации о компании...")
company_info, created = CompanyInfo.objects.get_or_create(
    pk=1,
    defaults={
        'about_text': """ООО «СтройДом» - это динамично развивающаяся строительная компания, специализирующаяся на возведении частных домов. 
        
С момента основания в 2014 году мы реализовали более 100 проектов, и каждый из них стал домом мечты для наших клиентов.

Наша команда - это профессионалы своего дела: архитекторы, инженеры, прорабы и строители с многолетним опытом работы. Мы используем только качественные материалы от проверенных поставщиков и современные технологии строительства.

Мы гордимся тем, что большинство наших клиентов приходят к нам по рекомендациям. Это лучшее подтверждение качества нашей работы и индивидуального подхода к каждому проекту.""",
        'mission': 'Создавать комфортные и надежные дома, в которых будут рады жить наши клиенты и их семьи. Мы стремимся к высокому качеству во всём и честным отношениям с заказчиками.',
        'vision': 'Стать лидером рынка загородного строительства в Московском регионе, известным своим профессионализмом, инновационным подходом и безупречной репутацией.',
        'years_experience': 10,
        'completed_projects': 100,
        'happy_clients': 150
    }
)
if created:
    print("✓ Создана информация о компании")

# Преимущества
print("\n3. Создание преимуществ...")
advantages_data = [
    {'title': 'Высокое качество', 'description': 'Используем только проверенные материалы и технологии строительства', 'icon': 'fa-award', 'order': 1},
    {'title': 'Соблюдение сроков', 'description': 'Строим точно в срок согласно договору без задержек', 'icon': 'fa-clock', 'order': 2},
    {'title': 'Гарантия', 'description': 'Даем гарантию на все виды выполненных работ', 'icon': 'fa-shield-alt', 'order': 3},
    {'title': 'Профессионализм', 'description': 'Команда опытных специалистов с высокой квалификацией', 'icon': 'fa-user-tie', 'order': 4},
    {'title': 'Прозрачное ценообразование', 'description': 'Фиксированная цена в договоре без скрытых платежей', 'icon': 'fa-ruble-sign', 'order': 5},
    {'title': 'Индивидуальный подход', 'description': 'Учитываем все пожелания клиента при проектировании', 'icon': 'fa-heart', 'order': 6},
]

for adv_data in advantages_data:
    Advantage.objects.get_or_create(title=adv_data['title'], defaults=adv_data)
print(f"✓ Создано {len(advantages_data)} преимуществ")

# Услуги
print("\n4. Создание услуг...")
services_data = [
    {
        'name': 'Проектирование',
        'slug': 'proektirovanie',
        'short_description': 'Разработка индивидуальных и адаптация типовых проектов',
        'description': """Профессиональное проектирование частных домов любой сложности. 
        
Мы предлагаем:
• Разработку индивидуальных проектов с нуля
• Адаптацию типовых проектов под ваши потребности
• 3D-визуализацию будущего дома
• Полный комплект проектной документации
• Согласование проекта в надзорных органах

Учитываем все ваши пожелания, особенности участка и бюджет.""",
        'icon': 'fa-drafting-compass',
        'price_from': 50000,
        'order': 1
    },
    {
        'name': 'Фундаментные работы',
        'slug': 'fundamentnye-raboty',
        'short_description': 'Устройство надежного фундамента любого типа',
        'description': """Качественное устройство фундамента - основа долговечности вашего дома.

Выполняем работы по устройству:
• Ленточного фундамента
• Плитного фундамента
• Свайно-ростверкового фундамента
• Свайно-винтового фундамента

Проводим геологические изыскания, расчет несущей способности, гидроизоляцию и утепление фундамента.""",
        'icon': 'fa-layer-group',
        'price_from': 300000,
        'order': 2
    },
    {
        'name': 'Возведение стен',
        'slug': 'vozvedenie-sten',
        'short_description': 'Строительство стен из различных материалов',
        'description': """Возведение несущих и ненесущих стен из различных материалов.

Работаем с материалами:
• Кирпич (керамический, силикатный)
• Газобетонные блоки
• Деревянный брус
• Каркасные конструкции

Обеспечиваем правильную геометрию, перевязку и армирование. Гарантируем теплоэффективность конструкций.""",
        'icon': 'fa-th-large',
        'price_from': 500000,
        'order': 3
    },
    {
        'name': 'Кровельные работы',
        'slug': 'krovelnye-raboty',
        'short_description': 'Монтаж кровли любой сложности',
        'description': """Устройство надежной кровли, защищающей дом от непогоды.

Виды кровли:
• Металлочерепица
• Гибкая черепица
• Натуральная черепица
• Фальцевая кровля
• Профнастил

Выполняем полный цикл работ: стропильная система, гидро- и теплоизоляция, монтаж кровельного покрытия, водосточная система.""",
        'icon': 'fa-home',
        'price_from': 400000,
        'order': 4
    },
    {
        'name': 'Отделочные работы',
        'slug': 'otdelochnye-raboty',
        'short_description': 'Внутренняя и внешняя отделка дома',
        'description': """Комплексная отделка дома - от черновой до чистовой.

Внутренняя отделка:
• Штукатурные работы
• Монтаж гипсокартона
• Укладка напольных покрытий
• Отделка потолков
• Малярные работы

Внешняя отделка:
• Фасадная штукатурка
• Облицовка кирпичом, камнем
• Монтаж сайдинга
• Утепление фасада""",
        'icon': 'fa-paint-roller',
        'price_from': 600000,
        'order': 5
    },
    {
        'name': 'Инженерные системы',
        'slug': 'inzhenernye-sistemy',
        'short_description': 'Монтаж всех инженерных коммуникаций',
        'description': """Проектирование и монтаж инженерных систем для комфортной жизни.

Выполняем работы:
• Электроснабжение
• Водоснабжение и канализация
• Отопление (котельная, радиаторы, теплые полы)
• Вентиляция и кондиционирование
• Системы безопасности

Используем качественное оборудование с гарантией производителя.""",
        'icon': 'fa-tools',
        'price_from': 400000,
        'order': 6
    }
]

for service_data in services_data:
    service, created = Service.objects.get_or_create(slug=service_data['slug'], defaults=service_data)
    if created:
        print(f"  ✓ Создана услуга: {service.name}")

print(f"✓ Создано {len(services_data)} услуг")

# Контактная информация
print("\n5. Создание контактной информации...")
contact_info, created = ContactInfo.objects.get_or_create(
    pk=1,
    defaults={
        'address': 'г. Москва, ул. Строителей, д. 10, офис 25',
        'phone': '+7 (495) 123-45-67',
        'email': 'info@stroydom.ru',
        'work_hours': 'Пн-Пт: 9:00-18:00, Сб: 10:00-16:00',
        'vk_url': 'https://vk.com/stroydom',
        'telegram_url': 'https://t.me/stroydom',
    }
)
if created:
    print("✓ Создана контактная информация")

# Категории новостей
print("\n6. Создание категорий новостей...")
news_categories = [
    {'name': 'Новости компании', 'slug': 'company-news', 'order': 1},
    {'name': 'Завершённые проекты', 'slug': 'completed-projects', 'order': 2},
    {'name': 'Акции и скидки', 'slug': 'promotions', 'order': 3},
    {'name': 'Полезные советы', 'slug': 'useful-tips', 'order': 4},
]

for cat_data in news_categories:
    NewsCategory.objects.get_or_create(slug=cat_data['slug'], defaults=cat_data)
print(f"✓ Создано {len(news_categories)} категорий новостей")

print("\n" + "="*50)
print("✅ Базовые данные успешно созданы!")
print("="*50)
print("\n📝 Учетные записи:")
print("  Администратор: admin / Admin2025!")
print("  Менеджер: manager / Manager2025!")
print("  Клиент: client / Client2025!")
print("\n🌐 Теперь можно запустить сервер: python manage.py runserver")

